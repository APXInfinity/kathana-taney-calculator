/* KATHANA EVENT MINI — THEMES
   Edit or duplicate any theme to create your own. All colors are #RRGGBB.
   5 original themes + 15 previous additions + 15 new additions = 35 built-in themes.
   Your in-app Skin Workshop also lets you create, save, import and export themes.
*/
window.KATHANA_THEMES = [
  // ORIGINAL FIVE
  {id:'winamp',name:'Classic Winamp',bg:'#282d41',panel:'#525b78',edge:'#8c94af',accent:'#adff71',text:'#f2f4f9',muted:'#c0c8d4',screen:'#09130e',button:'#767f9c',top:'#373e61'},
  {id:'dark',name:'Dark',bg:'#20232d',panel:'#343a46',edge:'#697281',accent:'#e3bd63',text:'#f1f2f6',muted:'#b8c1ce',screen:'#131922',button:'#414958',top:'#262d3c'},
  {id:'classic',name:'Classic Desktop',bg:'#acb1bb',panel:'#747e94',edge:'#3b475e',accent:'#122b4e',text:'#101b2a',muted:'#354254',screen:'#d7ded6',button:'#bfc6d2',top:'#65728a'},
  {id:'lcd',name:'Green LCD',bg:'#192b22',panel:'#264a35',edge:'#4c8c5f',accent:'#93ffa0',text:'#e2ffe7',muted:'#afd2b7',screen:'#061810',button:'#285c40',top:'#274f38'},
  {id:'light',name:'Clean Light',bg:'#f6f7fa',panel:'#e3e8ed',edge:'#9cabb9',accent:'#20654b',text:'#1e2938',muted:'#475c66',screen:'#eef4eb',button:'#d4e0e9',top:'#dbe4e9'},
  // FIFTEEN ADDITIONAL SKINS
  {id:'midnight',name:'Midnight Blue',bg:'#142039',panel:'#1d3357',edge:'#42678a',accent:'#73d9ff',text:'#e9f5ff',muted:'#b0c8dd',screen:'#08152b',button:'#294d77',top:'#15294b'},
  {id:'cyberpunk',name:'Cyberpunk',bg:'#21132e',panel:'#442150',edge:'#9c367a',accent:'#00f5d4',text:'#fff0fb',muted:'#e5b8dc',screen:'#140b24',button:'#64336a',top:'#531a50'},
  {id:'violet',name:'Neon Violet',bg:'#241630',panel:'#3c2459',edge:'#8252b3',accent:'#dd96ff',text:'#f6ecff',muted:'#cdb4e9',screen:'#130b25',button:'#67418e',top:'#473064'},
  {id:'ruby',name:'Ruby Red',bg:'#311a25',panel:'#5a2836',edge:'#9d4659',accent:'#ff8699',text:'#fff1f4',muted:'#eac0c7',screen:'#1b0a12',button:'#7a3449',top:'#572437'},
  {id:'amber',name:'Amber Radio',bg:'#332818',panel:'#5b4325',edge:'#9b7434',accent:'#ffcb65',text:'#fff7e4',muted:'#ddcba8',screen:'#21170a',button:'#795827',top:'#644a25'},
  {id:'ice',name:'Arctic Ice',bg:'#e4f0f7',panel:'#b6d8e6',edge:'#73a8ba',accent:'#176b89',text:'#0d3448',muted:'#375d6b',screen:'#cce9f2',button:'#9ec9d9',top:'#accdda'},
  {id:'forest',name:'Deep Forest',bg:'#1d2a24',panel:'#2d4637',edge:'#577561',accent:'#aeed9e',text:'#ebfff0',muted:'#bdd4bd',screen:'#101f15',button:'#3c5843',top:'#355440'},
  {id:'obsidian',name:'Obsidian Gold',bg:'#18191a',panel:'#2b2d30',edge:'#727473',accent:'#e6c878',text:'#f0eee7',muted:'#bcb9ae',screen:'#060708',button:'#3e4247',top:'#282b2e'},
  {id:'copper',name:'Copper Forge',bg:'#2f231f',panel:'#584035',edge:'#986952',accent:'#ffaf77',text:'#fff2e9',muted:'#dec6b7',screen:'#21130f',button:'#795343',top:'#6a4432'},
  {id:'ocean',name:'Ocean Depths',bg:'#122d39',panel:'#214957',edge:'#407f89',accent:'#78f0df',text:'#e7fbfb',muted:'#afd8db',screen:'#071b23',button:'#316475',top:'#205568'},
  {id:'retro',name:'Retro Beige',bg:'#e5d9bf',panel:'#c5ad83',edge:'#83765f',accent:'#54381c',text:'#34261a',muted:'#665642',screen:'#f3e8c9',button:'#d2bd98',top:'#cdb68e'},
  {id:'sakura',name:'Sakura',bg:'#fae6ee',panel:'#f2c8d8',edge:'#c88fa7',accent:'#983e65',text:'#533148',muted:'#784a62',screen:'#fceff3',button:'#dfafc2',top:'#e8b5cd'},
  {id:'matrix',name:'Terminal Matrix',bg:'#08100b',panel:'#122719',edge:'#2e7340',accent:'#4fff70',text:'#c2ffd0',muted:'#80b68b',screen:'#000900',button:'#184e28',top:'#154126'},
  {id:'carbon',name:'Carbon Fiber',bg:'#1d2022',panel:'#33393b',edge:'#697173',accent:'#e5f0f2',text:'#e8f0f3',muted:'#b6c4c8',screen:'#0a0e11',button:'#475054',top:'#282f32'},
  {id:'royal',name:'Royal Indigo',bg:'#1f1c45',panel:'#37336f',edge:'#6d65ac',accent:'#e4bdfc',text:'#f4f1ff',muted:'#c2bce6',screen:'#111132',button:'#4e4986',top:'#343064'},
  // FIFTEEN NEW v0.8 SKINS (TOTAL = 35)
  {id:'slate',name:'Slate Mercury',bg:'#202934',panel:'#344250',edge:'#8399ab',accent:'#e3e9ed',text:'#f6f8fa',muted:'#c4d2dc',screen:'#101820',button:'#4a5966',top:'#2c3b48'},
  {id:'crimson',name:'Crimson Circuit',bg:'#260f19',panel:'#491c2d',edge:'#9b3953',accent:'#ff648d',text:'#fff0f4',muted:'#e3b4c1',screen:'#10050a',button:'#72263d',top:'#541c2f'},
  {id:'mono',name:'Monochrome',bg:'#111111',panel:'#252525',edge:'#737373',accent:'#ffffff',text:'#eeeeee',muted:'#bdbdbd',screen:'#050505',button:'#454545',top:'#333333'},
  {id:'solar',name:'Solar Flare',bg:'#392015',panel:'#61351d',edge:'#bc6324',accent:'#ffdf79',text:'#fff5e5',muted:'#f0cdb0',screen:'#221208',button:'#965023',top:'#703b1a'},
  {id:'pearl',name:'Lunar Pearl',bg:'#eef0f5',panel:'#d6dce6',edge:'#8c99b1',accent:'#475f95',text:'#243249',muted:'#4b5a70',screen:'#f8faff',button:'#c0c9d9',top:'#d8deea'},
  {id:'tangerine',name:'Tangerine Drive',bg:'#25201b',panel:'#443122',edge:'#ad662a',accent:'#ffb058',text:'#fff2e5',muted:'#dac0a3',screen:'#140f08',button:'#755039',top:'#533621'},
  {id:'teal',name:'Electric Teal',bg:'#0a2729',panel:'#114f52',edge:'#2a9a95',accent:'#62ffec',text:'#e2fff9',muted:'#a8d9d5',screen:'#031718',button:'#24706f',top:'#126467'},
  {id:'plum',name:'Velvet Plum',bg:'#271a29',panel:'#4a2f4d',edge:'#896489',accent:'#efb7ed',text:'#fff1ff',muted:'#d8b9da',screen:'#130b1b',button:'#654369',top:'#513052'},
  {id:'synth',name:'Synthwave Sunset',bg:'#21192d',panel:'#50304c',edge:'#c05a8d',accent:'#ffc276',text:'#fff0fd',muted:'#e0b5d5',screen:'#150e2a',button:'#80406c',top:'#633450'},
  {id:'desert',name:'Desert Sand',bg:'#e9ddc7',panel:'#c8b69a',edge:'#938166',accent:'#69462d',text:'#30291f',muted:'#665546',screen:'#f7ecd9',button:'#b39e80',top:'#cfbda4'},
  {id:'lime',name:'Gunmetal Lime',bg:'#1c2226',panel:'#394346',edge:'#6b7978',accent:'#c8f85e',text:'#f3f9ee',muted:'#bacbb7',screen:'#0b1314',button:'#56645c',top:'#303c3c'},
  {id:'harbor',name:'Harbor Blue',bg:'#1b2b39',panel:'#2b4c64',edge:'#5a8dab',accent:'#acdfff',text:'#effaff',muted:'#b9d1e1',screen:'#0b1a25',button:'#416a87',top:'#365674'},
  {id:'mint',name:'Mint Circuit',bg:'#d9f6e9',panel:'#aadac7',edge:'#6da493',accent:'#205f51',text:'#133b32',muted:'#315d52',screen:'#effef7',button:'#87c1aa',top:'#a5d7c7'},
  {id:'roseq',name:'Rose Quartz',bg:'#f7e6e6',panel:'#e2c2cb',edge:'#b48298',accent:'#843e5b',text:'#51263a',muted:'#805569',screen:'#fff2f4',button:'#d8adb9',top:'#e5bdc8'},
  {id:'pixel',name:'Pixel Navy',bg:'#111b32',panel:'#223356',edge:'#526aa1',accent:'#92b9ff',text:'#eaf3ff',muted:'#a9c1e6',screen:'#070f20',button:'#364c83',top:'#2b4170'}
];
