﻿# Kathana Event Mini v0.8 - Win11 Edge app launcher + last-window-size keeper
# Local-only utility. No network fetch, no downloads, no elevated privileges.
param(
  [ValidateSet('last','regular','mini')]
  [string]$Mode = 'last'
)
$ErrorActionPreference = 'Stop'
# Avoid two background monitors fighting over one application window.
$createdNew = $false
$instanceLock = [System.Threading.Mutex]::new($true, 'Local\KathanaEventMini_WindowMonitor_v07', [ref]$createdNew)
if (-not $createdNew) {
  Write-Output 'Kathana Event Mini is already running. Use the in-app REGULAR/MINI switch.'
  exit 0
}
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$index = Join-Path $root 'index.html'
if (-not (Test-Path -LiteralPath $index -PathType Leaf)) { throw 'index.html missing. Extract the entire ZIP.' }

# Check shipped resources against a manifest BEFORE opening the widget.
# This catches accidental changes and basic post-download file tampering. It is not a cryptographic signature.
$manifest = Join-Path $root 'SHA256SUMS.txt'
if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw 'Integrity manifest is missing. Extract a fresh copy.' }
$expected = Get-Content -LiteralPath $manifest | Where-Object { $_ -match '^[0-9a-fA-F]{64}  [A-Za-z0-9._-]+$' }
if ($expected.Count -lt 7) { throw 'Incomplete integrity manifest. Extract a fresh copy.' }
foreach($line in $expected) {
    $hash = $line.Substring(0,64).ToUpperInvariant()
    $file = $line.Substring(66)
    $p = Join-Path $root $file
    if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { throw "Required local file missing: $file" }
    if ((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash -ne $hash) {
      throw "Integrity check failed: $file. Restore the official package before opening."
    }
}

$edgeCandidates = @(
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "${env:ProgramFiles}\Microsoft\Edge\Application\msedge.exe",
  "${env:LocalAppData}\Microsoft\Edge\Application\msedge.exe"
)
$edge = $edgeCandidates | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -First 1
if (-not $edge) { throw 'Microsoft Edge not found. You may still open index.html in a browser.' }

$stateDir = Join-Path $env:LOCALAPPDATA 'KathanaEventMini'
$profile = Join-Path $stateDir 'EdgeProfile'
$windowState = Join-Path $stateDir 'window.json'
New-Item -ItemType Directory -Path $stateDir -Force | Out-Null
# Separate browser profile makes it easier to isolate from normal browsing and preserve UI preferences.
New-Item -ItemType Directory -Path $profile -Force | Out-Null

$old = $null
if (Test-Path -LiteralPath $windowState -PathType Leaf) {
  try { $old = Get-Content -LiteralPath $windowState -Raw | ConvertFrom-Json -ErrorAction Stop } catch { $old = $null }
}
$layout = 'regular'
if ($old -and $old.mode -in @('regular','mini')) { $layout = $old.mode }
if ($Mode -ne 'last') { $layout = $Mode }
$width = if($layout -eq 'mini') { 264 } else { 326 }
$height = if($layout -eq 'mini') { 307 } else { 395 }
$posX = 60; $posY = 60
# The standard launcher restores the exact last user-adjusted OUTER window rectangle.
if ($Mode -eq 'last' -and $old) {
  try {
    if([int]$old.width -ge 200 -and [int]$old.width -le 2000){$width = [int]$old.width}
    if([int]$old.height -ge 170 -and [int]$old.height -le 1600){$height = [int]$old.height}
    if([int]$old.x -gt -20000 -and [int]$old.x -lt 20000){$posX = [int]$old.x}
    if([int]$old.y -gt -20000 -and [int]$old.y -lt 20000){$posY = [int]$old.y}
  } catch { }
}
# Ensure a previous monitor's location is on at least one visible display.
Add-Type -AssemblyName System.Windows.Forms
$visible = $false
foreach($monitor in [System.Windows.Forms.Screen]::AllScreens) {
  $area=$monitor.WorkingArea
  if (($posX+80) -gt $area.Left -and $posX -lt ($area.Right-80) -and
      ($posY+55) -gt $area.Top -and $posY -lt ($area.Bottom-55)) { $visible=$true; break }
}
if (-not $visible) {
  $area=[System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
  $posX=$area.Left+35; $posY=$area.Top+35
}

# Windows API: observe size and position of the Edge APP window in order to
# remember actual user resizing. The browser alone cannot reliably persist outer geometry.
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class KathanaNativeWin {
  public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr hWnd);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int maxCount);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);
  [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr hWnd, int x, int y, int width, int height, bool repaint);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  public class Window { public IntPtr Handle; public uint Pid; public string Title; public int X,Y,Width,Height; public bool Minimized; }
  public static List<Window> Enumerate(string titleFragment) {
    var found = new List<Window>();
    EnumWindows(delegate(IntPtr hwnd, IntPtr unused){
      if (!IsWindowVisible(hwnd)) return true;
      var text = new StringBuilder(512);
      GetWindowText(hwnd,text,text.Capacity);
      string title = text.ToString();
      if (!title.Contains(titleFragment)) return true;
      RECT r; uint pid;
      if (!GetWindowRect(hwnd,out r)) return true;
      GetWindowThreadProcessId(hwnd,out pid);
      found.Add(new Window { Handle=hwnd, Pid=pid, Title=title,
        X=r.Left,Y=r.Top,Width=r.Right-r.Left,Height=r.Bottom-r.Top,Minimized=IsIconic(hwnd) });
      return true;
    },IntPtr.Zero);
    return found;
  }
}
'@

# Build file:// URL with proper escaping for spaces, # and other path characters.
$uri = ([Uri]([IO.Path]::GetFullPath($index))).AbsoluteUri
if ($Mode -ne 'last' -or ($old -and $old.mode -in @('regular','mini'))) {
  $uri += '?size=' + $layout
}
$args = @(
  ('--user-data-dir="' + $profile + '"'),
  '--no-first-run', '--no-default-browser-check', '--disable-extensions', '--disable-sync',
  '--disable-background-mode', '--new-window',
  ('--window-position=' + $posX + ',' + $posY),
  ('--window-size=' + $width + ',' + $height),
  ('--app="' + $uri + '"')
)
Start-Process -FilePath $edge -ArgumentList $args -WindowStyle Normal | Out-Null

$firstSeen = $null
$lastSeen = Get-Date
$started = Get-Date
$lastBounds = $null
$lastMode = $null
$verifiedPid = $null
while ($true) {
  $all = [KathanaNativeWin]::Enumerate('Kathana Event Mini — ')
  # Only act on Edge windows, not arbitrary windows that imitate a title.
  $one = $null
  foreach($w in $all) {
    try {
      $p = Get-Process -Id $w.Pid -ErrorAction Stop
      if ($p.ProcessName -eq 'msedge' -and $p.Path -eq $edge -and
          $w.Width -ge 170 -and $w.Width -le 3000 -and $w.Height -ge 140 -and $w.Height -le 2000) {
        $one = $w
        break
      }
    } catch { }
  }
  if ($one) {
    $lastSeen = Get-Date
    if ($null -eq $firstSeen) { $firstSeen=Get-Date }
    if ($one.Minimized) {
      # Do not save off-screen (-32000,-32000) coordinates when the app is minimized.
      Start-Sleep -Milliseconds 330
      continue
    }
    $nowMode = if($one.Title -match 'Kathana Event Mini — MINI'){ 'mini' } else { 'regular' }
    if ($null -ne $lastMode -and $nowMode -ne $lastMode) {
      # Change OS window dimensions ONLY on an explicit REGULAR/MINI switch.
      $newWidth = if ($nowMode -eq 'mini') { 264 } else { 326 }
      $newHeight = if ($nowMode -eq 'mini') { 307 } else { 395 }
      [KathanaNativeWin]::MoveWindow($one.Handle,$one.X,$one.Y,$newWidth,$newHeight,$true) | Out-Null
      Start-Sleep -Milliseconds 80
      $updated = [KathanaNativeWin]::Enumerate('Kathana Event Mini — ') |
         Where-Object { $_.Pid -eq $one.Pid } | Select-Object -First 1
      if ($updated) { $one = $updated }
    }
    $lastMode = $nowMode
    $lastBounds = [pscustomobject]@{ x=$one.X; y=$one.Y; width=$one.Width; height=$one.Height; mode=$nowMode; savedAt=(Get-Date).ToString('o') }
  } elseif ($firstSeen -and ((Get-Date)-$lastSeen).TotalSeconds -gt 1.1) {
    break
  } elseif (-not $firstSeen -and ((Get-Date)-$started).TotalSeconds -gt 22) {
    throw 'Edge did not show the Kathana widget window. Please extract the ZIP and try again.'
  }
  Start-Sleep -Milliseconds 330
}
if ($lastBounds) {
  # Atomic-ish write: interrupted launcher does not corrupt prior geometry file.
  $temp = $windowState + '.tmp'
  $lastBounds | ConvertTo-Json -Compress | Set-Content -LiteralPath $temp -Encoding UTF8
  Move-Item -LiteralPath $temp -Destination $windowState -Force
}

$instanceLock.ReleaseMutex()
$instanceLock.Dispose()
