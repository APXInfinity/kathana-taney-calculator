@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
echo Running launcher in visible diagnostic mode.
echo If the app is already open, close it before running this file.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Launch-Kathana.ps1" -Mode last
if errorlevel 1 (
 echo.
 echo The launcher reported a problem. Check that files were extracted intact.
 pause
)
