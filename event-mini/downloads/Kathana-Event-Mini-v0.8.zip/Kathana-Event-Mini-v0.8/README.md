# Kathana Event Mini v0.8

**Unofficial, free, offline Kathana clock and automatic-event mini-widget for Windows.**

A very small Winamp-inspired tool showing **PH time (UTC+8)**, **server-schedule display time (UTC−3)**, the next automatic event, and a countdown. No Discord login, game login, installation, or paid service required. This clock reads the **Windows computer's clock**, not an authenticated Kathana game server time feed.

## Fast start — 30 seconds

1. Download `Kathana-Event-Mini-v0.8.zip` from the verified download link on the Kathana fan tools site or its GitHub release.
2. In Windows File Explorer, **right-click ZIP → Extract All**. You must extract it; don't run the launcher inside the ZIP.
3. Open the extracted folder, double-click **Launch Kathana Widget.bat**. Microsoft Edge on Windows 10/11 opens a borderless-tab app window (Windows title bar remains).
4. Choose **MINI** in the upper-right for a **248px** content layout; **REGULAR** for a **312px** layout. Both show PH and server clocks, the next event and the countdown.
5. Drag/resize the **outer Windows window**. Close using the normal **X**. Next launch with the main BAT restores your real last window position, size and selected layout.

Other launchers: **Launch Mini.bat** starts Mini intentionally, **Launch Regular.bat** starts Regular intentionally, **Troubleshoot Launcher.bat** shows error details. Don't run launchers as administrator.

## Buttons

- **MINI / REGULAR** — switch between 248px and 312px layouts. An explicit mode switch resets outer size to the mode's preset; subsequent manual resizing is remembered.
- **SKINS** — pick any of the **35 built-in** color themes, or create your own. See [SKINS-ELI5.md](SKINS-ELI5.md).
- **EVENTS** — view the next scheduled weekly events, with both PH/local and UTC−3 clocks. You can import a trusted `JSON` weekly schedule or restore the packaged snapshot.
- **NOTICES** — view known schedule limitations and source information.
- **OPTIONS** — select your local time zone, display size and reset local preferences.
- **⚙** — open options.

## Clock and automatic-event caveats

**Server time** is a fixed **UTC−3 reference** inferred from the game's posted event table. In the Philippines (**UTC+8**) it is **11 hours earlier**; both clocks use 12-hour AM/PM, not 24-hour notation. The times shown depend on your PC's correct system time. Set Windows `Set time automatically` to ON.

The app contains a local, repeating weekly schedule snapshot, not a live Discord recording or game API. Server patches and one-off events may change the times. Always verify against official Kathana announcements, especially before organized gameplay.

## Security and privacy

The app has **no analytics, remote JavaScript, ads, automatic updates, accounts, network sync or game credential entry**. Data is saved on your own PC. Imported JSON files are parsed as *data* and checked for proper structure; untrusted files are not executed as code. The browser uses the normal Edge sandbox. The launcher has a SHA-256 manifest that catches accidental edits to bundled files (it is not a publisher signature). See [SECURITY.md](SECURITY.md).

The **webpage about the widget** can separately display aggregate page visits, download clicks and thumbs-up votes once its own public counter service is configured. **Those statistics are not collected by the offline widget.**

## Where local settings are saved

- `%LOCALAPPDATA%\KathanaEventMini\window.json`: last outer size, X/Y position, Regular/Mini mode.
- `%LOCALAPPDATA%\KathanaEventMini\EdgeProfile`: isolated Edge browser storage, chosen theme and custom skins.
- To reset only the window: close the app and delete **only `window.json`**. To fully reset app-local browser settings, remove the EdgeProfile folder after closing all instances (custom skins are lost, so export first).

## Troubleshooting

- **Nothing opens:** extract the ZIP fully, then run `Troubleshoot Launcher.bat`. Check that Microsoft Edge is installed. Double-click launchers; do not elevate.
- **A blank page:** bundled JS may be missing/altered. Re-extract the genuine ZIP and check the bundled SHA256SUMS.txt.
- **Mini still has a large outer Windows border:** Edge/Windows can enforce minimum frame dimensions, especially at 150%+ display scaling. The content layout is 248px even if the outer frame stays larger. Use 100–125% Windows scaling if practical.
- **Server and PH clocks match:** verify that PC automatic time is on, and server is configured UTC−3. Differences should be 11 hours.
- **Events wrong:** check the in-app schedule source and official announcements. An imported schedule overrides the bundled one until restored.
- **Window on another monitor:** the launcher moves off-screen saved positions back to the primary monitor.
- **Want to edit skin colors:** use the built-in workshop, **not** JavaScript edits. Editing `.js` breaks the launcher's bundled checksum validation.

## Minimum files in the release

`index.html`, `app.js`, `style.css`, `themes.js`, `schedule.js`, `icon.svg`, `manifest.webmanifest`; three user-facing BAT launchers, one troubleshooting BAT, the monitored PowerShell launcher, SHA256SUMS.txt and three documentation files.

Source project: `kathana-taney-calculator/event-mini/` (until a separately named GitHub repository is created). Unofficial fan utility: not affiliated with the game or publisher.
