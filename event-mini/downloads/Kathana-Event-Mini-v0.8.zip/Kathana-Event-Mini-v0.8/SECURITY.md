# Security: Kathana Event Mini v0.8

## What this version does protect against

- **Remote content injection:** all app code runs from local files; no third-party JavaScript, iframes, fetch requests, game credentials or Discord connections. The HTML includes a restrictive Content Security Policy (CSP).
- **Malicious skin/event JSON:** imported files are parsed as data only, size-limited, and type-validated (colors must be `#RRGGBB`, schedules use numeric weekdays, `HH:MM`, plain names). Imported names are written using `textContent`, not untrusted HTML.
- **Accidental modification / simple tampering:** the launcher checks seven SHA-256 values from a manifest and fails closed if one is missing or differs.
- **Browser profile cross-contamination:** the Windows launcher uses a separate Edge user-data directory with extensions and sync disabled. Edge's own sandbox is not disabled.
- **Invisible telemetry:** no app analytics, update checker, network requests or cloud storage are implemented; settings remain on the computer. Clicking a visible external link is the only intended navigation.
- **Unexpected resizing on startup:** the launcher restores saved geometry; opening a drawer/skin does not call `resizeTo`. Only pressing the REGULAR/MINI toggle intentionally changes the window preset.

## What this version cannot protect against

- A deliberately replaced malicious download/ZIP, modified BAT/PowerShell launcher and forged checksum manifest: **not digitally signed**.
- Malware already installed on the same Windows profile, process injection, keyloggers, compromised Microsoft Edge/Windows, or malicious browser/OS vulnerabilities.
- Users intentionally following external links to compromised websites.
- Software that controls or interferes with Windows window geometry; certain Edge versions impose a minimum width/height that even Win32 calls cannot reliably override.
- Incorrect time if the Windows system clock is wrong or Kathana changes its published event schedule.

## Safety checklist

1. Obtain archives only from a trusted source. Scan with Windows Defender/SmartScreen if prompted.
2. Unzip the *complete folder* and run only the supplied `Launch Kathana Widget.bat` without administrator privileges.
3. Keep Edge and Windows updated and security protections enabled.
4. Don't accept `.exe`, `.bat`, `.ps1`, `.vbs` or other executable files as "skins". A legitimate skin is a simple `.json` file.
5. Do not override an integrity warning by turning off the check. Re-extract from a trusted ZIP.
6. The launcher uses Windows PowerShell with process-scoped execution-policy bypass because it includes an unsigned local launcher. It does not change your persistent PowerShell execution policy.

Security is a risk reduction process; **"invulnerable" cannot truthfully be guaranteed**. This fan tool is not a game client, anti-cheat or antivirus.
