@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if not exist "%~dp0index.html" (
 echo Missing index.html. Extract the entire ZIP first.
 pause
 exit /b 1
)
rem Launch the LOCAL PowerShell window monitor hidden, without a permanent console.
start "" powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Launch-Kathana.ps1" -Mode last
exit /b 0
