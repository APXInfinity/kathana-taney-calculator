/* Official site snapshot, checked 2026-11-06: https://playkathana.com/home
   Fixed server DISPLAY offset UTC-3. This is a weekly schedule, not a live server API.
   Correct for Friday 7:00 PM Baruna change (March 2026).
   Includes Saturday 11:00 AM Castle Siege.
   Event slots are WEEKLY (Mon=0 ... Sun=6), times are 24-hour INTERNAL DATA
   but ALL VISIBLE CLOCKS are 12-hour AM/PM.
   This can be replaced from within the widget via Events > Import Schedule JSON.
*/
(function(){
  'use strict';
  const schedule=[];
  const add=(day,time,name)=>schedule.push({day,time,name});
  for(let day=0;day<7;day++){
    if([0,2,4].includes(day)){
      add(day,'05:00','Kalia Dungeon');
      add(day,'06:00','Double Master Point');
      add(day,'07:00','High Kruma Event');
      add(day,'09:00','Baruna Knights Event');
      add(day,'11:00','Ananga Invasion');
      add(day,'16:00','Kalia Dungeon');
      add(day,'18:00','Anaka Kruma Event');
      add(day,day===4?'19:00':'18:00','Baruna Knights Event');
      add(day,'19:00','Double Master Point');
      add(day,'22:00','Ananga Invasion');
    }else{
      add(day,'05:00','Ananga Invasion');
      add(day,'06:00','Double Master Point');
      add(day,'09:00','Baruna Knights Event');
      add(day,'11:00','Kalia Dungeon');
      add(day,'13:00','High Kruma Event');
      add(day,'16:00','Ananga Invasion');
      add(day,'18:00','Baruna Knights Event');
      add(day,'19:00','Double Master Point');
      add(day,'22:00','Kalia Dungeon');
      add(day,'23:59','Anaka Kruma Event');
      if(day===5)add(day,'11:00','Castle Siege');
    }
  }
  window.KATHANA_DEFAULT_SCHEDULE=schedule;
  window.KATHANA_SCHEDULE_SOURCE={
    name:'Kathana official website — Automatic Events',
    url:'https://playkathana.com/home',
    checked:'2026-11-06',
    note:'Weekly repetition; times shown in UTC−3. Subject to server announcements and changes.'
  };
})();
