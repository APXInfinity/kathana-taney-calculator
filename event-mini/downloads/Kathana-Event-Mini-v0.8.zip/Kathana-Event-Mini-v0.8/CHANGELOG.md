# Changelog

## v0.8 — 2026-11-06
- Added 15 new built-in skins (total **35**).
- Raised local custom skin limit to 50; kept support for v0.6/v0.7 saved settings.
- Removed redundant `Launch Compact.bat` compatibility shortcut from distribution.
- Rewrote README and beginner skin-creation guide; kept SECURITY documentation.
- Preserved both PH and UTC−3 clocks, weekly event schedule, Mini/Regular toggle and Windows geometry persistence.
- Refreshed SHA-256 integrity manifest.

## v0.7
- Added window position/dimensions memory, regular 312px and Mini 248px layouts, added security controls.

## v0.6
- Added built-in themes and skin workshop, improved clock visibility and added schedule import/export.
