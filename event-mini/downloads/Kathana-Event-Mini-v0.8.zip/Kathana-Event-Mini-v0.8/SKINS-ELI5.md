# Make Your Own Kathana Skin — ELI5 Guide

**No programming needed.** The widget already has **35 built-in skins**. You can also save **up to 50 personal skins** using the nine color controls inside the widget.

## Make a new skin in 1 minute

1. Run **Launch Kathana Widget.bat**.
2. Click **SKINS** at the bottom of the widget.
3. First click a built-in skin close to the colors you want. This gives you a starting point.
4. Scroll to **MAKE YOUR OWN SKIN**.
5. Type a short name (for example `Ice Dragon`), then choose colors for the nine parts using the color boxes.
6. Click **SAVE & USE**. Your new design immediately appears in the skin list.
7. Reopen the widget any time. Your personal skin stays saved on **this computer**.

## What the nine color boxes do

| Box | What it colors | Beginner tip |
|---|---|---|
| Widget body (`bg`) | Outer background | Dark neutral colors look neat. |
| Panels (`panel`) | Inner body panels | Make slightly lighter than the body. |
| Borders (`edge`) | Lines, frames and separators | A medium contrast keeps edges visible. |
| Clock / accent (`accent`) | Large clock digits, highlights | Pick a color that stands out from the digital screen. |
| Main text (`text`) | Titles and event names | Light color for dark skins; dark for light skins. |
| Secondary text (`muted`) | Labels and smaller text | Don't make this too faint. |
| Digital screen (`screen`) | Clock background | Usually the darkest section on dark skins. |
| Buttons (`button`) | Menu buttons and controls | Different from the panel for clear buttons. |
| Title bar (`top`) | Top header strip | Use the same family as panel/body. |

### Easy first skin recipe

For a dark blue theme, start with: body `#142039`, panels `#1D3357`, borders `#42678A`, accent `#73D9FF`, main text `#E9F5FF`, secondary text `#B0C8DD`, digital screen `#08152B`, buttons `#294D77`, title bar `#15294B`.

For a readable skin, the clock and screen need strong contrast. Don't use similar colors for both. Preview your skin in **MINI**, because it has smaller labels.

## Share your skin with friends

1. Select your saved skin in **SKINS**.
2. Click **EXPORT CURRENT SKIN**. The widget downloads a tiny `.json` file (usually only a few hundred bytes).
3. Send **only that `.json` skin** to your friend; do not send app `.js`, `.bat`, or `.ps1` files.
4. Your friend opens **SKINS → IMPORT A SKIN JSON**, selects the file, and the widget validates its name and nine colors before saving.
5. Select the imported skin to use it.

### Example skin JSON

You can also create a JSON file using Notepad. Paste the sample below, save it as **My-Blue-Skin.json** (Save as type: **All Files**), and import it in the widget:

```json
{
  "name": "My Blue Skin",
  "bg": "#142039", "panel": "#1D3357", "edge": "#42678A",
  "accent": "#73D9FF", "text": "#E9F5FF", "muted": "#B0C8DD",
  "screen": "#08152B", "button": "#294D77", "top": "#15294B"
}
```

All nine color keys are required. Each value must contain a **#** and exactly **six hexadecimal digits**. HTML, JavaScript and CSS are **not skin formats**, and will be rejected.

## Fix common problems

- **Import says invalid:** check all nine keys and use double quotes in JSON. Avoid commas after the last item.
- **Fonts hard to see:** brighten `text` and `accent`, darken `screen` (or reverse for a light theme).
- **Can't find the new skin:** select **SKINS** again. It should appear below the built-ins.
- **Skin vanished on another computer:** skins live locally. Export `.json` and import it there.
- **Skin vanished after reset:** the Edge profile contains saved custom skins. Export favorites before deleting it.
- **A bundled theme file was edited:** re-extract a clean official ZIP. Change themes through the widget instead.

**Security:** Only use `.json` files from trusted friends; the widget validates them but cannot guarantee that your computer is safe from unrelated malicious programs. Never run `.bat`/`.ps1` skin files shared in game chats.
