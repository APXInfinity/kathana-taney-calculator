/* Kathana Auto-Event Clock v0.8 — all times based on the device's system time.
   The SERVER clock is the UTC−3 schedule DISPLAY clock, not a server-time API.
   No login, network request, telemetry, or web scraping. Offline-capable.
*/
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const S_ZONE = 'Etc/GMT+3'; // IANA's reversed sign means UTC−3
  const DAY = 86400000, HOUR = 3600000, WEEK = 7 * DAY;
  const DAYS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const ZONES = [
    ['Asia/Manila','Philippines (UTC+8)'],['Asia/Singapore','Singapore (UTC+8)'],
    ['Asia/Tokyo','Japan (UTC+9)'],['Asia/Jakarta','Indonesia — Jakarta (UTC+7)'],
    ['America/Sao_Paulo','Brazil — São Paulo'],['America/New_York','USA — New York'],
    ['America/Los_Angeles','USA — Los Angeles'],['Europe/London','UK — London'],
    ['Europe/Berlin','Germany — Berlin'],['UTC','UTC']
  ];
  function load(key,fallback){try{return localStorage.getItem(key) ?? fallback}catch{return fallback}}
  function save(key,value){try{localStorage.setItem(key,value)}catch{/* sandboxed local file */}}
  function parseJson(key,fallback){try{return JSON.parse(load(key,''))||fallback}catch{return fallback}}
  const THEMES = Array.isArray(window.KATHANA_THEMES) ? window.KATHANA_THEMES : [];
  const DEFAULT_EVENTS = Array.isArray(window.KATHANA_DEFAULT_SCHEDULE) ? window.KATHANA_DEFAULT_SCHEDULE : [];
  const COLOR_FIELDS = [
    ['bg','Widget body'],['panel','Panels'],['edge','Borders'],['accent','Clock / accent'],
    ['text','Main text'],['muted','Secondary text'],['screen','Digital screen'],['button','Buttons'],['top','Title bar']
  ];
  const hexColor = value => typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value);
  const safeName = name => String(name || '').trim().slice(0,30);
  const nameValid = n => n.length >= 2 && n.length <= 30 && !/[<>\\]/.test(n);
  function validateTheme(theme) {
    if(!theme || typeof theme !== 'object' || !nameValid(safeName(theme.name)))return false;
    return COLOR_FIELDS.every(([key])=>hexColor(theme[key]));
  }
  function validateSchedule(events) {
    return Array.isArray(events) && events.length >= 1 && events.length <= 300 && events.every(ev=>{
      if(!ev || !Number.isInteger(ev.day) || ev.day<0 || ev.day>6)return false;
      if(typeof ev.name !== 'string' || ev.name.trim().length < 2 || ev.name.length>90)return false;
      if(typeof ev.time!=='string' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(ev.time))return false;
      return true;
    });
  }
  let customThemes = parseJson('kathana-v06-custom-themes',[]);
  if(!Array.isArray(customThemes))customThemes=[];
  customThemes = customThemes.filter(validateTheme).slice(0,50);
  let weekly = parseJson('kathana-v06-weekly',DEFAULT_EVENTS);
  if(!validateSchedule(weekly)) weekly=DEFAULT_EVENTS;
  const savedZone = load('kathana-zone','Asia/Manila');
  const urlMode = new URLSearchParams(location.search).get('size');
  const zone = ZONES.some(x=>x[0]===savedZone)?savedZone:'Asia/Manila';
  const state = {
    theme:load('kathana-v06-theme','winamp'),
    mode:(urlMode === 'mini' || urlMode === 'regular') ? urlMode : ((load('kathana-v07-size','regular') === 'mini' || load('kathana-v06-size','')==='mini') ? 'mini':'regular'),
    zone,
    panel:null,
    editId:null,
    lastEventKey:'',
    nextEvents:[],
  };
  const ids = Object.freeze({localClock:$('localClock'),serverClock:$('serverClock'),
    localDate:$('localDate'),serverDate:$('serverDate'),yourLabel:$('yourLabel'),
    countdown:$('countdown'),slotCount:$('slotCount')});

  function getTheme(id){return [...THEMES,...customThemes].find(t=>t.id===id) || THEMES[0]}
  function chooseTheme(id){
    const theme = getTheme(id); if(!theme)return;
    state.theme=theme.id;save('kathana-v06-theme',state.theme);
    for(const [field] of COLOR_FIELDS)document.documentElement.style.setProperty('--'+field,theme[field]);
    const color = document.querySelector('meta[name="theme-color"]');if(color)color.content=theme.bg;
    if(state.panel==='skins')showSkins();
  }
  function timeAt(ms,tz,second=false,weekday=false){
    const opts={timeZone:tz,hour:'numeric',minute:'2-digit',hour12:true};
    if(second)opts.second='2-digit';
    if(weekday)opts.weekday='short';
    return new Intl.DateTimeFormat('en-US',opts).format(new Date(ms)).replace(/[\u202f\u00a0]/g,' ');
  }
  function dateAt(ms,tz){
    return new Intl.DateTimeFormat('en-US',{timeZone:tz,weekday:'short',month:'short',day:'numeric'}).format(new Date(ms));
  }
  function eventTimeHTML(ms){
    const l=timeAt(ms,state.zone,false,true),s=timeAt(ms,S_ZONE,false,true);
    return `<span class="local">${state.zone==='Asia/Manila'?'PH':'LOCAL'} ${l}</span><span class="sep">·</span><span class="server">SV ${s}</span>`;
  }
  // The weekly schedule lists MON..SUN in local UTC−3 calendar days.
  // Monday 00:00 UTC−3 corresponds to Monday 03:00 UTC.
  function getWeekStartUTC(ms){
    const serverVirtual=new Date(ms - 3*HOUR);
    const dow=(serverVirtual.getUTCDay()+6)%7;
    return Date.UTC(serverVirtual.getUTCFullYear(),serverVirtual.getUTCMonth(),serverVirtual.getUTCDate()) - dow*DAY + 3*HOUR;
  }
  function occurrences(ms){
    const base=getWeekStartUTC(ms),out=[];
    for(let weekOffset=-1;weekOffset<=1;weekOffset++){
      for(const evt of weekly){
        const [h,m]=evt.time.split(':').map(Number);
        out.push({name:evt.name,ts:base+weekOffset*WEEK+evt.day*DAY+h*HOUR+m*60000,day:evt.day});
      }
    }
    out.sort((a,b)=>a.ts-b.ts || a.name.localeCompare(b.name));
    return out;
  }
  function putEvent(prefix,ev){
    $(prefix+'Name').textContent=ev?.name||'—';
    $(prefix+'When').innerHTML=ev?eventTimeHTML(ev.ts):'—';
  }
  function fmtCountdown(secs){
    const pad=n=>String(n).padStart(2,'0');
    return `${pad(Math.floor(secs/3600))}:${pad(Math.floor(secs%3600/60))}:${pad(secs%60)}`;
  }
  function tick(){
    const now=Date.now();
    ids.localClock.textContent=timeAt(now,state.zone,true);
    ids.serverClock.textContent=timeAt(now,S_ZONE,true);
    ids.localDate.textContent=dateAt(now,state.zone);
    ids.serverDate.textContent=dateAt(now,S_ZONE);
    ids.yourLabel.textContent=state.zone==='Asia/Manila'?'PH · UTC+8':'LOCAL · '+state.zone.replaceAll('_',' ');
    const occ=occurrences(now),idx=occ.findIndex(e=>e.ts>now);
    if(idx<0)return;
    const prev=occ[idx-1],next=occ[idx],after=occ[idx+1];
    const key=[prev?.ts,next?.ts,after?.ts,state.zone,weekly.length].join('|');
    if(state.lastEventKey!==key){
      putEvent('prev',prev);putEvent('next',next);putEvent('after',after);
      state.lastEventKey=key;
      state.nextEvents=occ.slice(idx,idx+25);
      if(state.panel==='events')showEvents();
    }
    const secs=Math.max(0,Math.ceil((next.ts-now)/1000));
    ids.countdown.textContent=fmtCountdown(secs);
    $('nextRow').toggleAttribute('data-soon',secs<=300);
    ids.slotCount.textContent=weekly.length+' / WEEK';
  }
  // The Win32 launcher monitors a stable title and stores REAL outer window geometry.
  // JS saves the layout independently. Restoring geometry is the launcher's job.
  const DEFAULT_GEOMETRY = Object.freeze({regular:[326,395],mini:[264,307]});
  function updateTitle(){document.title='Kathana Event Mini — '+state.mode.toUpperCase()}
  function resizeWindow(){
    const [w,h]=DEFAULT_GEOMETRY[state.mode];
    try{window.resizeTo(w,h)}catch{/* Edge may enforce a minimum window */}
  }
  function setSize(mode,explicitUserAction=true){
    state.mode=mode==='mini'?'mini':'regular';
    $('widget').dataset.mode=state.mode;
    $('sizeToggle').textContent=state.mode==='mini'?'REGULAR ◫':'MINI ▣';
    $('sizeToggle').setAttribute('aria-label',state.mode==='mini'?'Switch to regular display':'Switch to mini display');
    save('kathana-v07-size',state.mode);
    updateTitle();
    // Only resize on an EXPLICIT mode switch. Never destroy a manually sized
    // window on startup, on a theme change, or when opening a settings drawer.
    if(explicitUserAction)resizeWindow();
  }
  function scheduleResize(){ /* intentionally no-op: do not override manual geometry */ }
  function hideDrawer(){
    state.panel=null;$('drawer').hidden=true;$('drawerBody').replaceChildren();
    document.querySelectorAll('.toolbar button').forEach(b=>b.dataset.active='false');scheduleResize();
  }
  function showPanel(name){
    if(state.panel===name){hideDrawer();return;}
    state.panel=name;$('drawer').hidden=false;
    document.querySelectorAll('.toolbar button').forEach(b=>b.dataset.active=b.dataset.panel===name?'true':'false');
    const views={events:showEvents,notices:showNotices,skins:showSkins,options:showOptions};
    if(views[name])views[name]();
    scheduleResize();
  }
  const create=(tag,txt,cls)=>{
    const n=document.createElement(tag);
    if(txt!==undefined)n.textContent=txt;
    if(cls)n.className=cls;
    return n;
  };
  function para(root,txt,className){const el=create('p',txt,className);root.append(el);return el}
  function button(txt,fn){const el=create('button',txt);el.type='button';el.addEventListener('click',fn);return el;}
  function showEvents(){
    $('drawerTitle').textContent='NEXT AUTO EVENTS';
    const root=$('drawerBody');root.replaceChildren();
    const desc=para(root,'Weekly schedule shown in both time zones. SV = server display UTC−3; PH = your chosen local time.');
    desc.className='';
    const list=create('div',undefined,'eventlist');root.append(list);
    state.nextEvents.slice(0,18).forEach(ev=>{
      const row=create('div',undefined,'eventline');
      row.append(create('span',ev.name,'eventtxt'));
      const when=create('span',undefined,'eventtime2');
      const l=create('div',(state.zone==='Asia/Manila'?'PH ':'LOCAL ')+timeAt(ev.ts,state.zone,false,true));
      const s=create('div','SV '+timeAt(ev.ts,S_ZONE,false,true));
      when.append(l,s);row.append(when);list.append(row);
    });
    para(root,'Schedule source: '+(window.KATHANA_SCHEDULE_SOURCE?.name||'Local list')+'; checked 2026-11-06. Does not query game server.').className='warning';
    const a=create('a','Open original event listing ↗','a-link');
    a.href='https://playkathana.com/home';a.target='_blank';a.rel='noopener noreferrer';root.append(a);
    const controls=create('div',undefined,'btnrow');
    controls.append(button('EXPORT SCHEDULE JSON',()=>downloadJson('kathana-events.json',weekly)));
    controls.append(button('RESTORE OFFICIAL LIST',()=>{if(confirm('Restore the built-in weekly event schedule?')){
      weekly=DEFAULT_EVENTS;save('kathana-v06-weekly',JSON.stringify(weekly));state.lastEventKey='';tick();showEvents();
    }}));root.append(controls);
    const fileInput=create('input');fileInput.type='file';fileInput.accept='.json,application/json';fileInput.id='scheduleFile';
    const label=create('label','IMPORT YOUR WEEKLY SCHEDULE (JSON)');label.htmlFor=fileInput.id;root.append(label,fileInput);
    para(root,'JSON entries use {"day":0,"time":"05:00","name":"Kalia Dungeon"}. Day 0 = Monday; 6 = Sunday. Imported schedules replace all events until restored.');
    fileInput.onchange=()=>importJson(fileInput,50000,(obj)=>{
      const data=Array.isArray(obj)?obj:obj?.events;
      if(!validateSchedule(data))throw Error('Invalid schedule: expected 1–300 entries; day 0–6, time HH:MM, name 2–90 characters.');
      weekly=data.map(e=>({day:e.day,time:e.time,name:e.name.trim()}));
      save('kathana-v06-weekly',JSON.stringify(weekly));state.lastEventKey='';tick();showEvents();
      alert('Imported '+weekly.length+' weekly event slots successfully.');
    });
  }
  function showNotices(){
    $('drawerTitle').textContent='NOTICES / INFORMATION';
    const root=$('drawerBody');root.replaceChildren();
    para(root,'This is an unofficial, offline timer. The displayed server clock is a fixed UTC−3 reference, not synchronized to a live game-server API.');
    para(root,'The timetable repeats weekly from bundled schedule.js (snapshot: November 6, 2026). Unexpected server maintenance and event changes are not detected automatically.');
    para(root,'For accurate countdowns, turn on Windows Settings → Time & language → Date & time → Set time automatically.');
    const a=create('a','Check official Kathana event information ↗','a-link');
    a.href='https://playkathana.com/home';a.target='_blank';a.rel='noopener noreferrer';root.append(a);
  }
  function showSkins(){
    $('drawerTitle').textContent='SKINS · '+(THEMES.length+customThemes.length)+' AVAILABLE';
    const root=$('drawerBody');root.replaceChildren();
    para(root,'Classic Winamp is the default. Choose a look below. All 35 built-in skins are bundled offline.');
    const grid=create('div',undefined,'skinchoices');root.append(grid);
    for(const t of [...THEMES,...customThemes]){
      const opt=button(t.name,()=>chooseTheme(t.id));opt.className='skinpick';opt.dataset.theme=t.id;
      if(state.theme===t.id)opt.classList.add('selected');
      const chips=create('span',undefined,'swatches');
      for(const field of ['bg','screen','accent']){const square=create('i');square.style.background=t[field];chips.append(square)}
      opt.prepend(chips);grid.append(opt);
    }
    const head=create('h3','MAKE YOUR OWN SKIN — NO CODING NEEDED');root.append(head);
    para(root,'Pick a starting theme, type a name, change the colors and click SAVE. The skin stays on this computer.');
    const nameLabel=create('label','NAME FOR YOUR NEW SKIN');const nameInput=create('input');nameInput.type='text';nameInput.id='customSkinName';nameInput.maxLength=30;nameInput.placeholder='My custom skin';nameLabel.htmlFor=nameInput.id;root.append(nameLabel,nameInput);
    const form=create('div',undefined,'formgrid');root.append(form);
    const colors={};let base=getTheme(state.theme) || THEMES[0];
    for(const [field,title] of COLOR_FIELDS){
      const lbl=create('label',title);const input=create('input');input.type='color';input.value=base[field];
      input.setAttribute('aria-label',title);lbl.append(input);form.append(lbl);colors[field]=input;
    }
    const action=create('div',undefined,'btnrow');root.append(action);
    action.append(button('SAVE & USE',()=>{
      const name=safeName(nameInput.value);
      if(!nameValid(name)){alert('Use a skin name of 2–30 letters (without angle brackets).');return;}
      const data={id:'custom-'+Date.now().toString(36),name};for(const [field] of COLOR_FIELDS)data[field]=colors[field].value;
      if(customThemes.length>=50){alert('Maximum 50 custom skins. Remove one to continue.');return;}
      customThemes.push(data);save('kathana-v06-custom-themes',JSON.stringify(customThemes));chooseTheme(data.id);
    }));
    action.append(button('EXPORT CURRENT SKIN',()=>{const selected=getTheme(state.theme);if(selected)downloadJson('kathana-skin-'+selected.id+'.json',selected)}));
    const importLabel=create('label','IMPORT A SKIN JSON');const input=create('input');input.type='file';input.accept='.json,application/json';input.id='skinFile';
    importLabel.htmlFor=input.id;root.append(importLabel,input);
    input.onchange=()=>importJson(input,8000,obj=>{
      if(!validateTheme(obj))throw Error('Invalid skin. It must have a name and all 9 colors in #RRGGBB format.');
      if(customThemes.length>=50)throw Error('Maximum 25 saved custom skins reached.');
      const item={...obj,id:'custom-'+Date.now().toString(36),name:safeName(obj.name)};
      customThemes.push(item);save('kathana-v06-custom-themes',JSON.stringify(customThemes));chooseTheme(item.id);
      alert('Skin imported: '+item.name);
    });
    if(state.theme.startsWith('custom-')){
      root.append(button('DELETE CURRENT CUSTOM SKIN',()=>{
        if(!confirm('Delete this custom skin from this computer?'))return;
        customThemes=customThemes.filter(t=>t.id!==state.theme);save('kathana-v06-custom-themes',JSON.stringify(customThemes));chooseTheme('winamp');
      }));
    }
  }
  function showOptions(){
    $('drawerTitle').textContent='DISPLAY & CLOCK SETTINGS';
    const root=$('drawerBody');root.replaceChildren();
    const lbl=create('label','YOUR LOCAL TIME ZONE');const sel=create('select');
    for(const [z,text] of ZONES){const o=create('option',text);o.value=z;sel.append(o)}
    sel.value=state.zone;
    lbl.append(sel);root.append(lbl);
    sel.onchange=()=>{state.zone=sel.value;save('kathana-zone',state.zone);state.lastEventKey='';tick()};
    const sizeTitle=create('h3','LAYOUT PRESETS');root.append(sizeTitle);
    const buttons=create('div',undefined,'btnrow');buttons.append(button('REGULAR · 312px',()=>{setSize('regular');showOptions()}));
    buttons.append(button('MINI · 248px',()=>{setSize('mini');showOptions()}));root.append(buttons);
    para(root,'REGULAR is now the old compact layout (312px). MINI removes the previous and following rows to fit a smaller 248px layout. Both keep the two clocks and next-event countdown. Resize the outer window manually if you prefer; your last size and position are restored by the Windows launcher when you close it. Edge may impose a minimum outer size.');
    const info=create('div',undefined,'boxline');root.append(info);
    info.append(create('strong','HOW THESE CLOCKS WORK'));
    para(info,'Server: UTC−3 fixed, matching Kathana’s posted event schedule. Local: your selected time zone (Philippines UTC+8 by default). These differ by 11 hours. Both display 12-hour AM/PM.');
    para(info,'Times repeat weekly even with no internet. This timer uses your computer clock; it is not connected to the game’s time service or Discord.');
    para(info,'For accuracy, keep Windows Date & Time → Set time automatically ON. Event times can change after game patches.');
    para(info,'Source verified from the game’s Automatic Events list on Nov 6, 2026. Friday Baruna is 7 PM server time. Saturday Castle Siege is 11 AM server time.');
    const source=create('a','Kathana official schedule ↗','a-link');source.href='https://playkathana.com/home';source.target='_blank';source.rel='noopener noreferrer';root.append(source);
    const actions=create('div',undefined,'btnrow');root.append(actions);
    actions.append(button('RESET ALL PREFERENCES',()=>{
      if(!confirm('Reset skins, clock zone, layout, and custom schedule?'))return;
      ['kathana-zone','kathana-v06-size','kathana-v07-size','kathana-v06-theme','kathana-v06-weekly','kathana-v06-custom-themes'].forEach(k=>{try{localStorage.removeItem(k)}catch{}});
      location.reload();
    }));
  }
  function importJson(input,maxSize,cb){
    const f=input.files?.[0];if(!f)return;
    if(f.size>maxSize){alert('JSON file is too large.');input.value='';return;}
    const reader=new FileReader();
    reader.onload=()=>{
      try{const obj=JSON.parse(String(reader.result));cb(obj)}catch(err){alert('Import rejected: '+(err.message||'Invalid JSON'))}
      input.value='';
    };
    reader.onerror=()=>{alert('Could not read the selected file.');input.value=''};
    reader.readAsText(f);
  }
  function downloadJson(name,obj){
    const blob=new Blob([JSON.stringify(obj,null,2)+'\n'],{type:'application/json'});
    const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;
    document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);
  }
  $('sizeToggle').onclick=()=>setSize(state.mode==='regular'?'mini':'regular');
  $('settingsButton').onclick=()=>showPanel('options');
  $('closeDrawer').onclick=hideDrawer;
  document.querySelectorAll('.toolbar button').forEach(b=>b.onclick=()=>showPanel(b.dataset.panel));
  if(!getTheme(state.theme))state.theme='winamp';
  chooseTheme(state.theme);setSize(state.mode,false);tick();setInterval(tick,1000);
  // 1/week repeating events with source evidence, not an authenticated server feed.
  window.KATHANA_TEST={getWeekStartUTC,occurrences,timeAt,fmtCountdown,validateSchedule};
})();
